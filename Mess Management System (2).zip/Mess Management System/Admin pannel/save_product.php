<?php
  // get the form data
  $product_name = $_POST['product_name'];
  $price = $_POST['price'];
  $stock_in = $_POST['stock_in'];
  $stock_out = $_POST['stock_out'];
 
  // connect to the database
  $db_host = 'localhost';
  $db_username = 'root';
  $db_password = '';
  $db_name = 'mess_db';
  $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
  if (!$conn) {
    die('Could not connect: ' . mysqli_error());
  }

  // insert the new product into the database
  $sql = "INSERT INTO food (product_name, price, stock_in, stock_out) VALUES ('$product_name', '$price', '$stock_in', '$stock_out' )";
  if (mysqli_query($conn, $sql)) {
    echo "New product added successfully";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  // close the database connection
  mysqli_close($conn);
?>
