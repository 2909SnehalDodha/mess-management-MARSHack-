<?php
  // include('./admin_dashboard.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Food Inventory</title>
  <style>
    table {
      border-collapse: collapse;
      width: 80%;
    }
    th, td {
      text-align: left;
      padding: 8px;
    }
    th {
      background-color: #4CAF50;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    tr:hover {
      background-color: #ddd;
    }

    .edit-button {
      background-color: #008CBA;
      color: white;
      border: none;
      padding: 5px 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      margin: 2px;
      cursor: pointer;
    }

    .delete-button {
      background-color: #f44336;
      color: white;
      border: none;
      padding: 5px 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      margin: 2px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Food Inventory</h1>
 <form method="GET">
    <input type="text" name="search" placeholder="Search by Product Name or Price">
    <button type="submit" class="button">Search</button>
  </form>
  <br>
  
  <a href="admin_dashboard.php" class="button"><b>Back to Dashboard</b></a>
  <center>
    <a href="add_product.php">
      <h3>Add Product </h3>
    </a>
  </center>

  <table>
    <tr>
      <th>ID</th>
      <th>Product Name</th>
      <th>Price</th>
      <th>Stock In</th>
      <th>Stock Out</th>
      <th>Actions</th>
    </tr>
    <?php
      // connect to the database
      $db_host = 'localhost';
      $db_username = 'root';
      $db_password = '';
      $db_name = 'mess_db';
      $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
      if (!$conn) {
        die('Could not connect: ' . mysqli_error());
      }
      // get the search term from the URL parameter
      $searchTerm = $_GET['search'];

      // construct the SQL query
      $sql = "SELECT * FROM food WHERE product_name LIKE '%$searchTerm%' OR price LIKE '%$searchTerm%'";

      // execute the query
      $result = mysqli_query($conn, $sql);

           // loop through the result set and display each product in a table row
      while ($row = mysqli_fetch_assoc($result)) {
        $stock_available = $row['stock_in'] - $row['stock_out'];
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['product_name'] . '</td>';
        echo '<td>' . $row['price'] . '</td>';
        echo '<td>' . $row['stock_in'] . '</td>';
        echo '<td>' . $row['stock_out'] . '</td>';
        echo '<td>';
        echo '<button class="edit-button">';
        echo '<a href="edit_product.php?id='. $row['id'].'">Edit</a>';
        echo '</button>';
        echo '<button class="delete-button">';
        echo '<a href="delete.php?id=' . $row['id'] . '">Delete</a>';
        echo '</button>';
          echo '</td>';
          echo '</tr>';
        }

        // close the database connection
        mysqli_close($conn);
      ?>
    </tbody>
  </table>
</body>
</html>