$productNo            = $_REQUEST['product_number'];
$productTransaction   = $_REQUEST['tx']; 
$productPrice         = $_REQUEST['amt']; 
$productCurrency      = $_REQUEST['cc']; 
$price = '200.00';
$currency='INR';
 
if($productPrice==$price && $productCurrency==$currency)
{
    echo "Your Payment Successful, Good Luck";
}
else
{
    echo "Sorry, Dear Your Payment Failed";
}
echo "Payment Canceled";
$paypalUrl='https://www.sandbox.paypal.com/cgi-bin/webscr';
INTO
$paypalUrl='https://www.paypal.com/cgi-bin/webscr';