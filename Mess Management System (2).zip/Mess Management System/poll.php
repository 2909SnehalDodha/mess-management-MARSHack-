<?php
  include('includes/header.php');
  include('includes/connection.php');
  if(isset($_SESSION['email'])){
    if(isset($_POST['submit'])){
      $question = $_POST['question'];
      $option1 = $_POST['option1'];
      $option2 = $_POST['option2'];
      $option3 = $_POST['option3'];
      $option4 = $_POST['option4'];
      $created_by = $_SESSION['uid'];
      $query = "INSERT INTO polls(question, option1, option2, option3, option4, created_by) VALUES ('$question', '$option1', '$option2', '$option3', '$option4', '$created_by')";
      $query_run = mysqli_query($connection,$query);
      if($query_run){
        echo "<script type='text/javascript'>
          alert('Poll submitted successfully...');
          window.location.href = 'user_dashboard.php';
        </script>";
      }
      else{
        echo "<script type='text/javascript'>
          alert('Submission failed...Plz try again.');
          window.location.href = 'user_dashboard.php';
        </script>";
      }
    }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Create Poll</title>
  </head>
  <body><br>
    <div class="row">
      <div class="col-md-6 m-auto">
        <center><h5><u>Create Poll</u></h5></center>
        <form action="" method="post">
          <div class="form-group">
            <label>Question:</label>
            <input type="text" class="form-control" name="question" required>
          </div>
          <div class="form-group">
            <label>Option 1:</label>
            <input type="text" class="form-control" name="option1" required>
          </div>
          <div class="form-group">
            <label>Option 2:</label>
            <input type="text" class="form-control" name="option2" required>
          </div>
          <div class="form-group">
            <label>Option 3:</label>
            <input type="text" class="form-control" name="option3" required>
          </div>
          <div class="form-group">
            <label>Option 4:</label>
            <input type="text" class="form-control" name="option4" required>
          </div>
          <button class="btn btn-primary" type="submit" name="submit">Submit</button><br>
        </form>
      </div>
    </div>
  </body>
</html>
<?php
  }
  else{
    header('location:index.php');
  }
