<!DOCTYPE html>
<html lang="en">
<head>
    <title>Paypal Payment Gateway</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }

        h2 {
            margin-bottom: 50px;
        }


        .price .panel-heading {
            color: #fff;
            background-color: #1338BE;
            border-color: #FF6062;
            border-bottom: 1px solid #FF6062;
        }

        .price .panel-body {
            background-color: #F1F1F1;
        }

        .price .list-group-item {
            border: none;
        }

        .price .btn {
            border-radius: 0px;
            border: none;
            background-color: #1338BE;
            color: #fff;
            box-shadow: none;
        }

        .price .btn:hover {
            background-color: #1E42B3;
        }

        .price .btn:focus {
            box-shadow: none;
        }

        .price .btn:active {
            background-color: #1338BE;
        }
        .panel.price {
  border: 1px solid #000000;
}
input[type="radio"] {
  background-color: lightblue;
  border-radius: 50%;
  padding: 10px;
  margin-right: 10px;
}

    </style>
</head>
<body>
    <?php
        $paypalUrl = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
        $paypalId = 'solankirupal29721@gmail.com';
    ?>

    <div class="container text-center">
        <h2><strong>Paypal Payment Gateway</strong></h2>
        <div class="row justify-content-center">
            <div class="col-xs-12 col-sm-6 col-md-4">
               <form action="<?php echo $paypalUrl; ?>" method="post" name="frmPayPal1">
  <div class="panel price">
    <input type="hidden" name="business" value="<?php echo $paypalId; ?>">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="product_name" value="Pakainfo website">
    <input type="hidden" name="product_number" value="2">
    <input type="hidden" name="no_shipping" value="1">
    <input type="hidden" name="currency_code" value="INR">
    <input type="hidden" name="cancel_return" value="http://demo.pakainfo.com/paypal/cancel.php">
    <input type="hidden" name="return" value="http://demo.pakainfo.com/paypal/success.php">

    <div class="panel-heading">
      <h3>Bill Payment</h3>
    </div>
    <div class="panel-body">
      <p class="lead" style="font-size:40px"><strong>Choose a Subscription plan:</strong></p>
      <ul class="list-group list-group-flush">
        <li class="list-group-item"><input type="radio" name="amount" value="50"> INR 50 per day</li>
        <li class="list-group-item"><input type="radio" name="amount" value="300"> INR 300 per week</li>
        <li class="list-group-item"><input type="radio" name="amount" value="1000"> INR 1000 per month</
     </div>
    <ul class="list-group list-group-flush text-center">
      <li class="list-group-product"><i class="icon-ok text-danger"></i> </li>
      <li class="list-group-product"><i class="icon-ok text-danger"></i> </li>
    </ul>
    <div class="panel-footer">
      <button class="btn btn-lg btn-block btn-danger" href="#">PAY NOW!</button>
    </div>
  </div>
  <a href="images/p.jpeg"><b><u><h4> Scan This QR Code  </u></b></a></h4>
</form>

      
    </div>
  </div>
</div>
</body>
</html>