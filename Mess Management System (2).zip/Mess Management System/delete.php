<?php
// connect to the database
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'mess_db';
$conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);

// check for connection errors
if (mysqli_connect_errno()) {
  die('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// check if the product id is set
if (isset($_GET['id'])) {
  // prepare and bind the SQL statement
  $stmt = mysqli_prepare($conn, "DELETE FROM food WHERE id=?");
  mysqli_stmt_bind_param($stmt, 'i', $id);

  // get the product id from the URL parameter
  $id = $_GET['id'];

  // execute the statement and check for errors
  if (mysqli_stmt_execute($stmt)) {
    // check if any rows were affected
    if (mysqli_stmt_affected_rows($stmt) > 0) {
      // redirect to the home page
      header('Location: index.php');
      exit;
    } else {
      echo 'Error deleting product: no rows were affected.';
    }
  } else {
    echo 'Error deleting product: ' . mysqli_stmt_error($stmt);
  }

  // close the statement
  mysqli_stmt_close($stmt);
}

// close the database connection
mysqli_close($conn);
?>
