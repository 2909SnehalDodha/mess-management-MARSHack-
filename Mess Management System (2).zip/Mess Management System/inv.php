<?php
  include('includes/admin_dashboard.php');
  if(isset($_SESSION['email'])){
    include('includes/connection.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Food Inventory</title>
  <style>
    table {
      border-collapse: collapse;
      width: 80%;
    }
    th, td {
      text-align: left;
      padding: 8px;
    }
    th {
      background-color: #4CAF50;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;}

      tr:hover {
      background-color: #ddd;
    }

    .link-button {
  background: none;
  border: none;
  padding: 0;
  font: inherit;
  text-align: left;
  text-decoration: underline;
  cursor: pointer;
  color: blue;
}

.link-button:hover {
  text-decoration: none;
}

  </style>
</head>
<body>
  <h1>Food Inventory</h1>
  <a href="add_product.php">Add Product</a>
  <table>
    <tr>
      <th>ID</th>
      <th>Product Name</th>
      <th>Price</th>
      <th>Stock In</th>
      <th>Stock Out</th>
      <!-- <th>Stock Available</th> -->
      <th>Actions</th>
    </tr>
    <?php
      // connect to the database
      $db_host = 'localhost';
      $db_username = 'root';
      $db_password = '';
      $db_name = 'mess_db';
      $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
      if (!$conn) {
        die('Could not connect: ' . mysqli_error());
      }

      // select all products from the database
      $sql = "SELECT * FROM food";
      $result = mysqli_query($conn, $sql);

      // loop through the result set and display each product in a table row
      while ($row = mysqli_fetch_assoc($result)) {
        $stock_available = $row['stock_in'] - $row['stock_out'];
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['product_name'] . '</td>';
        echo '<td>' . $row['price'] . '</td>';
        echo '<td>' . $row['stock_in'] . '</td>';
        echo '<td>' . $row['stock_out'] . '</td>';
        echo '<td>' . $row['actions'] . '</td>';
        

        echo '<td>';
       

        echo '<button class="link-button">
        <a href="edit_product.php?id='. $row['id'].'">Edit</a>
      </button>';
      
        echo '<a href="delete.php?id=' . $row['id'] . '">Delete</a>';
        echo '</td>';
        echo '</tr>';
      }

// close the database connection
mysqli_close($conn);
}
?>