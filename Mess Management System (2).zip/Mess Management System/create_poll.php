<?php
session_start();
if(!isset($_SESSION['email'])){
  header('location:login.php');
  exit();
}
$is_admin = $_SESSION['is_admin'];
if(!$is_admin){
  header('location:user_dashboard.php');
  exit();
}

include('includes/connection.php');
$question = $_POST['question'];
$option1 = $_POST['option1'];
$option2 = $_POST['option2'];
$option3 = $_POST['option3'];
$option4 = $_POST['option4'];
$created_by = $_SESSION['uid'];

$query = "INSERT INTO polls (question, option1, option2, option3, option4, created_by) VALUES ('$question', '$option1', '$option2', '$option3', '$option4', '$created_by')";
$query_run = mysqli_query($connection, $query);

if($query_run){
  echo "<script type='text/javascript'>
        alert('Poll created successfully...');
        window.location.href = 'admin_dashboard.php';
      </script>";
} else {
  echo "<script type='text/javascript'>
        alert('Failed to create poll...Please try again.');
        window.location.href = 'admin_dashboard.php';
      </script>";
}
?>
