<?php
  $servername = "localhost";
  $username = "username";
  $password = "password";
  $dbname = "mess_db";

  // Create connection
  $conn = mysqli_connect($servername, $username, $password,mess_db);

  // Check connection
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
?>
<?php
  $sql = "SELECT fname, lname, mobile, address, fee_status FROM users";
  $result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Student Information</title>
    <style>
      table {
        border-collapse: collapse;
        width: 100%;
      }

      th, td {
        text-align: left;
        padding: 8px;
        border-bottom: 1px solid #ddd;
      }

      th {
        background-color: #f2f2f2;
      }
    </style>
  </head>
  <body>
    <h1>Student Information</h1>
    <table>
      <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Mobile</th>
        <th>Address</th>
        <th>Fee Paid</th>
      </tr>
      <?php
        // Loop through rows of data and display on webpage
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>";
          echo "<td>" . $row['fname'] . "</td>";
          echo "<td>" . $row['lname'] . "</td>";
          echo "<td>" . $row['mobile'] . "</td>";
          echo "<td>" . $row['address'] . "</td>";
          echo "<td>" . $row['fee_status'] . "</td>";
          echo "</tr>";
        }
      ?>
    </table>
  </body>
</html>
