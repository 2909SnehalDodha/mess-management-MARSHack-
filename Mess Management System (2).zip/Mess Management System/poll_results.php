<?php
// Connect to the database
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "mess_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Get the poll results
$sql = "SELECT * FROM poll WHERE id = 1";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Calculate the total votes
$total_votes = $row["votes1"] + $row["votes2"]+$row["votes3"] + $row["votes4"];

// Display the poll results
echo "<h2>" . $row["question"] . "</h2>";
echo $row["option1"] . ": " . $row["votes1"] . " votes (" . round(($row["votes1"] / $total_votes) * 100) . "%)<br>";
echo $row["option2"] . ": " . $row["votes2"] . " votes (" . round(($row["votes2"] / $total_votes) * 100) . "%)<br>";
echo $row["option3"] . ": " . $row["votes3"] . " votes (" . round(($row["votes3"] / $total_votes) * 100) . "%)<br>";
echo $row["option4"] . ": " . $row["votes4"] . " votes (" . round(($row["votes4"] / $total_votes) * 100) . "%)<br>";
echo "Total votes: " . $total_votes;

// Close the database connection
$conn->close();
?>
