-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2023 at 08:32 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mess_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `sno` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`sno`, `fname`, `lname`, `email`, `password`, `mobile`) VALUES
(1, 'Admin', 'Admin', 'admin@gmail.com', 'admin@123', 9988776655);

-- --------------------------------------------------------

--
-- Table structure for table `attendance1`
--

CREATE TABLE `attendance1` (
  `sno` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendance` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance1`
--

INSERT INTO `attendance1` (`sno`, `id`, `date`, `attendance`) VALUES
(1, 1, '2023-03-28', 'Present'),
(2, 2, '2023-03-29', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `attendance2`
--

CREATE TABLE `attendance2` (
  `sno` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendance` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance2`
--

INSERT INTO `attendance2` (`sno`, `id`, `date`, `attendance`) VALUES
(1, 1, '2023-03-23', 'Present'),
(2, 2, '2023-03-24', 'Present'),
(3, 4, '0000-00-00', 'Present'),
(4, 1, '0000-00-00', 'Present'),
(5, 1, '0000-00-00', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `attendance3`
--

CREATE TABLE `attendance3` (
  `sno` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendance` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance3`
--

INSERT INTO `attendance3` (`sno`, `id`, `date`, `attendance`) VALUES
(1, 1, '2023-03-30', 'Absent'),
(2, 2, '2023-03-31', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `attendance4`
--

CREATE TABLE `attendance4` (
  `sno` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendance` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance4`
--

INSERT INTO `attendance4` (`sno`, `id`, `date`, `attendance`) VALUES
(1, 1, '2023-03-28', 'Present');


-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `sno` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `date` date NOT NULL,
  `rating` varchar(100) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`sno`, `uid`, `date`, `rating`, `feedback`) VALUES
(2, 2, '2021-04-16', 'Good', 'Food is awesome'),
(3, 1, '2021-04-16', 'Excellent', 'Delicious food.');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `sno` int(11) NOT NULL,
  `day` varchar(100) NOT NULL,
  `meal1` varchar(250) NOT NULL,
  `meal2` varchar(250) NOT NULL,
  `meal3` varchar(250) NOT NULL,
  `meal4` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`sno`, `day`, `meal1`, `meal2`, `meal3`, `meal4`) VALUES
(1, 'Monday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(2, 'Tuesday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(3, 'Wednesday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(4, 'Thursday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(5, 'Friday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(6, 'Saturday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.'),
(7, 'Sunday', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.', 'Pohe, Milk, Egg', 'Daal, Chapati, Mix vegetable and salad.');

-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE `poll` (
  `sno` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `option1` varchar(100) NOT NULL,
  `option2` varchar(100) NOT NULL,
  `option3` varchar(100) NOT NULL,
  `option4` varchar(100) NOT NULL,
  `votes1` int(6) NOT NULL,
  `votes2` int(6) NOT NULL,
  `votes3` int(6) NOT NULL,
  `votes4` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` bigint(12) NOT NULL,
  `address` varchar(250) NOT NULL,
  `fee_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `fname`, `lname`, `email`, `password`, `mobile`, `address`, `fee_status`) VALUES
(1, 'ashok Kumar', 'Meena', 'ashok@gmail.com', 'ashok@123', 7742424214, 'ashok address goes here...', 1),
(2, 'rahul', 'Meena', 'rahul@gmail.com', 'rahul@123', 9942549875, 'rahul address goes here...', 1),
(3, 'Rohit', 'Sharma', 'rohit@gmail.com', 'rohit@123', 9999999998, 'Rohit address...', 1),
(5, 'Varshil', 'Jaskiya', 'vjaskiya@gmail.com', '123', 7567806833, '12 saibaba nagar part-2 sattadhar socitey road amriwadi ahmedabad 380026\r\nSAIBABA NAGAR PART-2', 1),
(6, 'Varshil', 'Jaskiya', 'vjaskiya@gmail.com', '123', 7567806833, '12 saibaba nagar part-2 sattadhar socitey road amriwadi ahmedabad 380026\r\nSAIBABA NAGAR PART-2', 0),
(7, 'snehal', 'dodha', 'dodhasnehal@gmail.com', 'snehal1234', 9316788497, 'ahmedabad', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `attendance1`
--
ALTER TABLE `attendance1`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `attendance2`
--
ALTER TABLE `attendance2`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `attendance3`
--
ALTER TABLE `attendance3`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `attendance4`
--
ALTER TABLE `attendance4`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `attendance1`
--
ALTER TABLE `attendance1`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `attendance2`
--
ALTER TABLE `attendance2`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `attendance3`
--
ALTER TABLE `attendance3`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `attendance4`
--
ALTER TABLE `attendance4`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;