<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Product</title>
</head>
<body>
  <h1>Add Product</h1>
  <form method="post" action="save_product.php">
    <label for="product_name">Product Name:</label>
    <input type="text" name="product_name" required><br><br>
    <label for="price">Price:</label>
    <input type="number" name="price" step="0.01" required><br><br>
    <label for="stock_in">Stock In:</label>
    <input type="number" name="stock_in" required><br><br>
    <label for="stock_out">Stock Out:</label>
    <input type="number" name="stock_out" required><br><br>
    <input type="submit" value="Save">
  </form>
</body>
</html>
