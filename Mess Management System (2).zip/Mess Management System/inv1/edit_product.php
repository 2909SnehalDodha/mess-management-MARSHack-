<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Product</title>
</head>
<body>
  <?php
    // connect to the database
    $db_host = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $db_name = 'product';
    $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
    if (!$conn) {
      die('Could not connect: ' . mysqli_error());
    }

    // get the product data
    $id = $_GET['id'];
    $sql = "SELECT * FROM food WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // close the database connection
    mysqli_close($conn);
  ?>

  <h1>Edit Product</h1>
  <form method="post" action="save_product.php">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <label for="product_name">Product Name:</label>
    <input type="text" name="product_name" value="<?php echo $row['product_name']; ?>" required><br><br>
    <label for="price">Price:</label>
    <input type="number" name="price" step="0.01" value="<?php echo $row['price']; ?>" required><br><br>
    <label for="stock_in">Stock In:</label>
    <input type="number" name="stock_in" value="<?php echo $row['stock_in']; ?>" required><br><br>
    <label for="stock_out">Stock Out:</label>
    <input type="number" name="stock_out" value="<?php echo $row['stock_out']; ?>" required><br><br>
    <input type="submit" value="Update">
  </form>
</body>
</html>
