<?php
// connect to the database
$db_host = 'localhost';
$db_username = 'your_db_username';
$db_password = 'your_db_password';
$db_name = 'your_db_name';
$conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
if (!$conn) {
  die('Could not connect: ' . mysqli_error());
}

// check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // get the form data
  $id = $_POST['id'];
  $product_name = $_POST['product_name'];
  $price = $_POST['price'];
  $stock_in = $_POST['stock_in'];
  $stock_out = $_POST['stock_out'];

  // update the product in the database
  $sql = "UPDATE food SET product_name='$product_name', price='$price', stock_in='$stock_in', stock_out='$stock_out' WHERE id=$id";
  if (mysqli_query($conn, $sql)) {
    // redirect to the home page
    header('Location: index.php');
    exit;
  } else {
    echo 'Error updating product: ' . mysqli_error($conn);
  }
}

// get the product details from the database
$id = $_GET['id'];
$sql = "SELECT * FROM food WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Product</title>
</head>
<body>
  <h1>Edit Product</h1>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <label for="product_name">Product Name:</label>
    <input type="text" name="product_name" id="product_name" value="<?php echo $row['product_name']; ?>"><br>
    <label for="price">Price:</label>
    <input type="number" name="price" id="price" value="<?php echo $row['price']; ?>"><br>
    <label for="stock_in">Stock In:</label>
    <input type="number" name="stock_in" id="stock_in" value="<?php echo $row['stock_in']; ?>"><br>
    <label for="stock_out">Stock Out:</label>
    <input type="number" name="stock_out" id="stock_out" value="<?php echo $row['stock_out']; ?>"><br>
    <input type="submit" value="Update Product">
  </form>
</body>
</html>
