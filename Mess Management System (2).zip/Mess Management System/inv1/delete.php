<?php
// connect to the database
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'product';
$conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
if (!$conn) {
  die('Could not connect: ' . mysqli_error());
}

// check if the product id is set
if (isset($_GET['id'])) {
  $id = $_GET['id'];

  // delete the product from the database
  $sql = "DELETE FROM food WHERE id=$id";
  if (mysqli_query($conn, $sql)) {
    // redirect to the home page
    header('Location: index.php');
    exit;
  } else {
    echo 'Error deleting product: ' . mysqli_error($conn);
  }
}

// close the database connection
mysqli_close($conn);
?>
